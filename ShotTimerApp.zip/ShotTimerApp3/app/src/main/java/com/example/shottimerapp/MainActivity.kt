package com.example.shottimerapp // Kendi paket adınızı kullanın

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.log10

class MainActivity : AppCompatActivity() {

    // Arayüz Elemanları
    private lateinit var tvTimer: TextView
    private lateinit var btnStart: Button
    private lateinit var btnReset: Button
    private lateinit var lvSplitTimes: ListView

    // Zamanlayıcı ve Ses İşleme Değişkenleri
    private var isTimerRunning = false
    private var isListening = false
    private var startTime: Long = 0
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var splitTimesAdapter: ArrayAdapter<String>
    private val splitTimes = mutableListOf<String>()

    // Ses Kaydı için
    private var audioRecord: AudioRecord? = null
    private var bufferSize = 0
    private val sampleRate = 44100
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT
    private val channelConfig = AudioFormat.CHANNEL_IN_MONO

    // Atış Algılama Eşiği (Bu değeri test ederek ayarlamanız gerekebilir)
    private val SHOT_THRESHOLD = 25000.0

    // Sabitler
    private val AUDIO_PERMISSION_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Arayüz elemanlarını bağlama
        tvTimer = findViewById(R.id.tvTimer)
        btnStart = findViewById(R.id.btnStart)
        btnReset = findViewById(R.id.btnReset)
        lvSplitTimes = findViewById(R.id.lvSplitTimes)

        // ListView için adapter kurulumu
        splitTimesAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, splitTimes)
        lvSplitTimes.adapter = splitTimesAdapter

        // Buton dinleyicileri
        btnStart.setOnClickListener {
            if (isTimerRunning) {
                stopTimer()
            } else {
                checkAudioPermissionAndStart()
            }
        }

        btnReset.setOnClickListener {
            resetTimer()
        }
    }

    // Mikronfon iznini kontrol et ve zamanlayıcıyı başlat
    private fun checkAudioPermissionAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_CODE)
        } else {
            startTimer()
        }
    }

    // İzin isteği sonucunu yönet
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == AUDIO_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startTimer()
            } else {
                Toast.makeText(this, "Mikrofon izni gerekli!", Toast.LENGTH_LONG).show()
            }
        }
    }

    // Zamanlayıcıyı başlatır
    private fun startTimer() {
        isTimerRunning = true
        btnStart.text = "Durdur"
        resetTimerValues()

        // Başlangıç sinyali (bip sesi)
        val tone = ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 100)
        tone.startTone(ToneGenerator.TONE_CDMA_PIP, 200)

        // Rastgele bir gecikme sonrası zamanlayıcıyı başlat (genellikle 1-3 saniye)
        val delay = (1000..3000).random().toLong()
        handler.postDelayed({
            startTime = System.currentTimeMillis()
            handler.post(timerRunnable)
            startListening()
        }, delay)
    }

    // Zamanlayıcıyı durdurur
    private fun stopTimer() {
        isTimerRunning = false
        btnStart.text = "Başlat"
        handler.removeCallbacks(timerRunnable)
        stopListening()
    }

    // Zamanlayıcıyı ve listeyi sıfırlar
    private fun resetTimer() {
        stopTimer()
        resetTimerValues()
    }

    private fun resetTimerValues(){
        tvTimer.text = "0.00"
        splitTimes.clear()
        splitTimesAdapter.notifyDataSetChanged()
    }


    // Zamanlayıcıyı güncelleyen Runnable
    private val timerRunnable = object : Runnable {
        override fun run() {
            if (isTimerRunning) {
                val elapsedMillis = System.currentTimeMillis() - startTime
                val seconds = elapsedMillis / 1000.0
                tvTimer.text = String.format("%.2f", seconds)
                handler.postDelayed(this, 30) // ~30 FPS güncelleme
            }
        }
    }

    // Mikrofonu dinlemeye başlar
    private fun startListening() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return // İzin yoksa başlama
        }

        bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        audioRecord = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channelConfig, audioFormat, bufferSize)

        isListening = true
        audioRecord?.startRecording()

        // Ses verisini ayrı bir thread'de işle
        thread {
            val buffer = ShortArray(bufferSize)
            var lastShotTime = 0L

            while (isListening) {
                val readSize = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                if (readSize > 0) {
                    // Maksimum genliği (amplitude) bul
                    var maxAmplitude = 0.0
                    for (s in buffer) {
                        if (abs(s.toDouble()) > maxAmplitude) {
                            maxAmplitude = abs(s.toDouble())
                        }
                    }

                    // Eşik değeri aşıldı mı kontrol et
                    val currentTime = System.currentTimeMillis()
                    // Bir önceki atıştan sonra 200ms geçmişse yeni atışı kabul et (yankı/çift algılamayı önler)
                    if (maxAmplitude > SHOT_THRESHOLD && (currentTime - lastShotTime > 200)) {
                        lastShotTime = currentTime
                        val elapsedMillis = currentTime - startTime
                        val seconds = elapsedMillis / 1000.0

                        // Arayüzü ana thread'de güncelle
                        runOnUiThread {
                            val splitTimeStr = String.format("Atış %d: %.2f s", splitTimes.size + 1, seconds)
                            splitTimes.add(splitTimeStr)
                            splitTimesAdapter.notifyDataSetChanged()
                        }
                    }
                }
            }
        }
    }

    // Mikrofonu dinlemeyi durdurur
    private fun stopListening() {
        if (isListening) {
            isListening = false
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopListening() // Uygulama kapanırken kaynakları serbest bırak
    }
}